<?php 

namespace b\b;

class Index
{
    public function greet($greet = "Hello World")
    {
        return $greet;
    }
}

